<?php
 
  // include database and object files
  include_once '../config/database.php';
   
  // instantiate database and product object
  $database = new Database();
  $db = $database->getConnection();

  if (isset($_POST['sellerID'])) { 
    $query = "SELECT id, firstname, lastname, email, contact_number FROM affliate_users WHERE id = '".$_POST["sellerID"]."'"; 
    $stmt = $db->prepare( $query );
    $stmt->execute();
 
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($row);
  }




?>