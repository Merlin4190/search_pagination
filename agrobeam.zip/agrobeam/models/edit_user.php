<?php
 
  // include database and object files
  include_once '../config/database.php';
   
  // instantiate database and product object
  $database = new Database();
  $db = $database->getConnection();

  if (isset($_POST['userID'])) { 
    $query = "SELECT id, firstname, lastname, email, contact_number FROM users WHERE id = '".$_POST["userID"]."'"; 
    $stmt = $db->prepare( $query );
    $stmt->execute();
 
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($row);
  }




?>