<?php

  // include database and object files
  include_once '../config/database.php';
   
  // instantiate database and product object
  $database = new Database();
  $db = $database->getConnection();

  if (isset($_POST['subID'])) { 
    $query = "SELECT id, catID, subname FROM sub_categories WHERE id = '".$_POST["subID"]."'"; 
    $stmt = $db->prepare( $query );
    $stmt->execute();
 
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($row); 
  }

  ?>