<?php
 
  // include database and object files
  include_once '../config/database.php';
   
  // instantiate database and product object
  $database = new Database();
  $db = $database->getConnection();

  if (isset($_POST['catID'])) { 
    $query = "SELECT id, name FROM categories WHERE id = '".$_POST["catID"]."'"; 
    $stmt = $db->prepare( $query );
    $stmt->execute();
 
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($row);
  }




?>