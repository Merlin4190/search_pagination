<?php

  function errorMessage($str) {
    return '<div style="width:50%; margin:0 auto; border:2px solid #F00;padding:2px; color:#000; margin-top:10px; text-align:center;">' . $str . '</div>';
  }

  function successMessage($str) {
    return '<div style="width:50%; margin:0 auto; border:2px solid #06C;padding:2px; color:#000; margin-top:10px; text-align:center;">' . $str . '</div>';
  }

  function slug($text){ 

    // replace non letter or digits by -
    $text = preg_replace('~[^\\pL\d]+~u', '-', $text);

    // trim
    $text = trim($text, '-');

    // transliterate
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

    // lowercase
    $text = strtolower($text);

    // remove unwanted characters
    $text = preg_replace('~[^-\w]+~', '', $text);

    if (empty($text))
    {
      return 'n-a';
    }

    return $text;
  }

  function product(){
     
    // instantiate database and product object
    $database = new Database();
    $db = $database->getConnection();

    if ($_POST) {

      $name = $_POST['productName'];
      $price = $_POST['price'];
      $unitPrice = $_POST['unitPrice'];
      $visibility = 1;
      $description = $_POST['description'];
      $other_info = $_POST['other_info'];
      $catID = $_POST['catID'];
      $subID = $_POST['subID'];
      $sellerID = $_SESSION['user_id'];
      // $productSlug = $slug($name);
      $flag = 0;
      
      if (!$name) {
        
        $error = "<br />Please enter a name for your product";
      }

      if (!$description) {
        
        $error = "<br />Please give a brief description of your product";
      }

      if (!$price) {
        
        $error = "<br />Please enter product's price"; 
      }
      if ($error) {
        
        throw new Exception ("<br /><div class='alert alert-danger'><span class='fa fa-info-circle'> Unable to add product.".$error."</span></div>");

      }else{

        $productSlug = slug($name);

        $stmt2 = $db->prepare('INSERT INTO products SET 
                                  name=:name, price=:price, unitPrice=:unitPrice, visibility=:visibility, 
                                  description=:description, additional_information=:other_info, catID=:catID, subID=:subID, sellerID=:sellerID, productSlug=:productSlug, flag=:flag, created=:created') ;
              $stmt2->execute(array(                
                  ':sellerID' => $sellerID,
                  ':subID' => $subID,
                  ':catID' => $catID,
                  ':name' => $name,
                  ':description' => $description,
                  ':other_info' => $other_info,
                  ':flag' => $flag,
                  ':price' => $price,
                  ':unitPrice' => $unitPrice,
                  ':productSlug' => $productSlug,
                  ':visibility' => $visibility,
                  ':created' => date('Y-m-d H:i:s')
        ));

        $productID = $db->lastInsertId();

        //add categories
        // if(is_array($catID)){
        //   foreach($_POST['catID'] as $catID){
        //     $stmt3 = $db->prepare('INSERT INTO product_cats (productID,catID)VALUES(:productID,:catID)');
        //     $stmt3->execute(array(
        //       ':productID' => $productID,
        //       ':catID' => $catID
        //     ));
        //   }
        // }

        // include resized library
          require_once('../../../objects/php-image-magician/php_image_magician.php');
          $msg = "";
          $valid_image_check = array("image/gif", "image/jpeg", "image/jpg", "image/png", "image/bmp");
          if (count($_FILES["imagefiles"]) > 0) {
            $folderName = "../../../libs/assets/uploads/";
            // if not, create it
            if(!is_dir($folderName)){
                mkdir($folderName, 0777, true);
            }
            $folderThumb = "../../../libs/assets/uploads/thumb";
            if(!is_dir($folderThumb)){
                mkdir($folderThumb, 0777, true);
            }

            $sql = "INSERT INTO product_images(productID,imageFile,created_at) VALUES (:productID,:img,:created_at)";
            $stmt = $db->prepare($sql);

            for ($i = 0; $i < count($_FILES["imagefiles"]["name"]); $i++) {

              if ($_FILES["imagefiles"]["name"][$i] <> "") {

                $image_mime = strtolower(image_type_to_mime_type(exif_imagetype($_FILES["imagefiles"]["tmp_name"][$i])));
                // if valid image type then upload
                if (in_array($image_mime, $valid_image_check)) {

                  $ext = explode("/", strtolower($image_mime));
                  $ext = strtolower(end($ext));
                  $filename = rand(10000, 990000) . '_' . time() . '.' . $ext;
                  $filepath = $folderName . $filename;

                  if (!move_uploaded_file($_FILES["imagefiles"]["tmp_name"][$i], $filepath)) {
                                $emsg .= "Failed to upload <strong><span class='fa fa-info-circle'>  " . $_FILES["imagefiles"]["name"][$i] . "</span></strong>. <br>";
                                $counter++;
                            } else {
                                $smsg .= "<strong><span class='fa fa-info-circle'> " . $_FILES["imagefiles"]["name"][$i] . "</span></strong> uploaded successfully. <br>";

                                $magicianObj = new imageLib($filepath);
                                $magicianObj->resizeImage(500, 500);
                      $magicianObj->saveImage($folderName . 'thumb/' . $filename, 100);

                    /*             * ****** insert into database starts ******** */
                    try {
                      $stmt->bindValue(":productID", $productID);
                      $stmt->bindValue(":img", $filename);
                      $stmt->bindValue(":created_at", date('Y-m-d H:i:s'));
                      $stmt->execute();
                      $result = $stmt->rowCount();
                      if ($result > 0) {
                        // file uplaoded successfully.
                      } else {
                        // failed to insert into database.
                      }
                    } catch (Exception $ex) {
                      $emsg .= "<strong>" . $ex->getMessage() . "</strong>. <br>";
                    }
                    /*             * ****** insert into database ends ******** */
                  }
                } else {
                          $emsg .= "<strong><span class='fa fa-info-circle'> " . $_FILES["imagefiles"]["name"][$i] . "</span></strong> not a valid image. <br>";
                        }
              }
            }

            $msg .= (strlen($smsg) > 0) ? successMessage($smsg) : "";
            $msg .= (strlen($emsg) > 0) ? errorMessage($emsg) : "";
          } else {
            $msg = errorMessage("You must upload atleast one file");
          }

        throw new Exception ("<br /><div class='alert alert-success'><span class='fa fa-info-circle'> Product added.</span></div>");
      }
    }
  }
?>