<?php
//database credentials
define('DBHOST','localhost');
define('DBUSER','root');
define('DBPASS','');
define('DBNAME','agrobeam_db');

try{

$db = new PDO("mysql:host=".DBHOST.";port=3306;dbname=".DBNAME, DBUSER, DBPASS);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
  echo $e->getMessage();
}

// $todays_date = date('Ymd', mktime (0, 0, 0, date ('m'), date ('d'), date ('Y')));
// echo $todays_date;

// $stmt = $db->prepare('SELECT expiration FROM subscriptions WHERE expiration = :t_date AND status = :status');
// $stmt->execute(array(
//   ':t_date' => date('Y-m-d')." 00:00:00",
//   ':status' => 1
// )); 
// while ($row = $stmt->fetch()) {
//   $expiry_date = date('Ymd', strtotime($row['expiration']));
//   echo $expiry_date;

  // if ($stmt->rowcount()) {
    $stmt = $db->prepare('UPDATE subscriptions SET status = :status WHERE expiration = :t_date AND status = 1');
    $stmt->execute(array(
      ':t_date' => date('Y-m-d')." 00:00:00",
      ':status' => 0
    ));
  // }
// }

?>