# Weather Icons
*Version 1.3 - November 30th, 2014*

These are the Bootstrap ready Less files. Put the "weather-icons" folder inside your main Less folder and import it with the rest of your less imports.

**Remember** your CSS is going to look for the fonts in `./css`, a directory above. 