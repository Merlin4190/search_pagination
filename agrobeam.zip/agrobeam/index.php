<?php
// core.php holds pagination variables
include_once 'config/core.php';
 
// include database and object files
include_once 'config/database.php';
include_once 'objects/user.php';
include_once 'objects/product.php';
// require_once "objects/shopping_cart.php";
// include_once 'objects/category.php';
 
// instantiate database and product object
$database = new Database();
$db = $database->getConnection();

$update_sub = $db->prepare('UPDATE subscriptions SET status = :status WHERE expiration = :t_date AND status = 1');
$update_sub->execute(array(
  ':t_date' => date('Y-m-d')." 00:00:00",
  ':status' => 0
));
 
$product = new Product($db);
$user = new User($db);
// $category = new Category($db);

// set ID property of user to be edited
if (isset($_SESSION['user_id'])) {

  $user->id = $_SESSION['user_id']; 
  
  // query user
  $stmt = $user->readOne();
}
 
$page_title = "AgroBeam | Life is Green";
include_once "views/layouts/layout_header.php";
 
// query products
$stmt = $product->readAll($from_record_num, $records_per_page);
// $stmt2 = $category->readAll();

 
// specify the page where paging is used
$page_url = "index.php?";
 
// count total rows - used for pagination
$total_rows=$product->countAll();
 
// read_template.php controls how the product list will be rendered
include_once "views/read_template.php";
 
// layout_footer.php holds our javascript and closing html tags
include_once "views/layouts/layout_footer.php";
?>

