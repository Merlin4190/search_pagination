<?php
class Category{
 
    // database connection and table name
    private $conn;
    private $table_name = "categories";
 
    // object properties
    public $id;
    public $name;
    public $imageFile;
 
    public function __construct($db){
        $this->conn = $db;
    }

    function slug($text){ 

      // replace non letter or digits by -
      $text = preg_replace('~[^\\pL\d]+~u', '-', $text);

      // trim
      $text = trim($text, '-');

      // transliterate
      $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

      // lowercase
      $text = strtolower($text);

      // remove unwanted characters
      $text = preg_replace('~[^-\w]+~', '', $text);

      if (empty($text))
      {
        return 'n-a';
      }

      return $text;
    }

    // create category
    function create(){
 
        //write query
        // insert query
        $query = "INSERT INTO " . $this->table_name . "
                    SET name=:name, catSlug=:catSlug, imageFile = :avatar, created=:created";
 
        $stmt = $this->conn->prepare($query);
 
        // posted values
        $this->name=htmlspecialchars(strip_tags($this->name));
        $this->catSlug=htmlspecialchars(strip_tags($this->catSlug));
        $this->avatar=htmlspecialchars(strip_tags($this->avatar));
 
        // to get time-stamp for 'created' field
        $this->timestamp = date('Y-m-d H:i:s');
 
        // bind values 
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":catSlug", $this->catSlug);
        $stmt->bindParam(':avatar', $this->avatar);
        $stmt->bindParam(":created", $this->timestamp);
 
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
 
    }

    // will upload image file to server
    function uploadPhoto(){
     
        $result_message="";
     
        // now, if image is not empty, try to upload the image        

        if($this->avatar){
     
            // sha1_file() function is used to make a unique file name
            $target_directory = "category_images/";
            $target_file = $target_directory . $this->avatar;
            $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
     
            // error message is empty
            $file_upload_error_messages="";

            // make sure that file is a real image
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check!==false){
                // submitted file is an image
            }
             
            // make sure certain file types are allowed
            $allowed_file_types=array("jpg", "jpeg", "png", "gif", "pdf");
            if(!in_array($file_type, $allowed_file_types)){
                $file_upload_error_messages.="<div>Only JPG, JPEG, PNG, GIF, PDF files are allowed.</div>";
            }
             
            // make sure file does not exist
            if(file_exists($target_file)){
                $file_upload_error_messages.="<div>File already exists. Try to change file name.</div>";
            }
             
            // make sure submitted file is not too large, can't be larger than 5 MB
            if($_FILES['image']['size'] > (5024000)){
                $file_upload_error_messages.="<div>File must be less than 5 MB in size.</div>";
            }
             
            // make sure the 'uploaded_documents' folder exists
            // if not, create it
            if(!is_dir($target_directory)){
                mkdir($target_directory, 0777, true);
            }

            // if $file_upload_error_messages is still empty
            if(empty($file_upload_error_messages)){
                // it means there are no errors, so try to upload the file
                if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
                    // it means photo was uploaded
                }else{
                    $result_message.="<div class='error'>";
                        $result_message.="<div>Unable to upload photo.</div>";
                        $result_message.="<div>Update the record to upload category image.</div>";
                    $result_message.="</div>";
                }
            }
             
            // if $file_upload_error_messages is NOT empty
            else{
                // it means there are some errors, so show them to user
                $result_message.="<div class='error'>";
                    $result_message.="{$file_upload_error_messages}";
                    $result_message.="<div>Update the record to upload category image.</div>";
                $result_message.="</div>";
            }
     
        }
     
        return $result_message;
    }

    // update category
    function update(){
 
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    name = :name,
                    catSlug = :catSlug,
                    imageFile = :avatar,
                    id = :id,
                    modified = :modified
                WHERE
                    id = :id";
     
        $stmt = $this->conn->prepare($query);
     
        // posted values
        $this->name=htmlspecialchars(strip_tags($this->name));
        $this->id=htmlspecialchars(strip_tags($this->id));
        $this->catSlug=htmlspecialchars(strip_tags($this->catSlug));
        $this->avatar=htmlspecialchars(strip_tags($this->avatar));

        // to get time-stamp for 'created' field
        $this->timestamp = date('Y-m-d H:i:s');
     
        // bind parameters
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':id', $this->id);
        $stmt->bindParam(":catSlug", $this->catSlug);
        $stmt->bindParam(':avatar', $this->avatar);
        $stmt->bindParam(":modified", $this->timestamp);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
         
    }

    // will upload image file to server
    function uploadUpdatedAvatar(){
     
        $result_message="";
     
        // now, if image is not empty, try to upload the image        

        if($this->avatar){
     
            // sha1_file() function is used to make a unique file name
            $target_directory = "category_images/";
            $target_file = $target_directory . $this->avatar;
            $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
     
            // error message is empty
            $file_upload_error_messages="";

            // make sure that file is a real image
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check!==false){
                // submitted file is an image
            }else{
                $file_upload_error_messages.="<div>Submitted file is not an image.</div>";
            }
             
            // make sure certain file types are allowed
            $allowed_file_types=array("jpg", "jpeg", "png", "gif", "pdf");
            if(!in_array($file_type, $allowed_file_types)){
                $file_upload_error_messages.="<div>Only JPG, JPEG, PNG, GIF, PDF files are allowed.</div>";
            }
             
            // make sure file does not exist
            if(file_exists($target_file)){
                $file_upload_error_messages.="<div>File already exists. Try to change file name.</div>";
            }
             
            // make sure submitted file is not too large, can't be larger than 5 MB
            if($_FILES['image']['size'] > (5024000)){
                $file_upload_error_messages.="<div>File must be less than 5 MB in size.</div>";
            }
             
            // make sure the 'uploaded_documents' folder exists
            // if not, create it
            if(!is_dir($target_directory)){
                mkdir($target_directory, 0777, true);
            }

            // if $file_upload_error_messages is still empty
            if(empty($file_upload_error_messages)){
                // it means there are no errors, so try to upload the file
                if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
                    // it means photo was uploaded
                }else{
                    $result_message.="<div class='error'>";
                        $result_message.="<div>Unable to upload photo.</div>";
                        $result_message.="<div>Update the record to upload avatar.</div>";
                    $result_message.="</div>";
                }
            }
             
            // if $file_upload_error_messages is NOT empty
            else{
                // it means there are some errors, so show them to user
                $result_message.="<div class='error'>";
                    $result_message.="{$file_upload_error_messages}";
                    $result_message.="<div>Update the record to upload avatar.</div>";
                $result_message.="</div>";
            }
     
        }
     
        return $result_message;
    }

    // read one category
    function readOne(){
 
        $query = "SELECT id, name
            FROM " . $this->table_name . "
            WHERE id = '".$_POST["catID"]."'
            LIMIT 0,1";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->id);
        $stmt->execute();
     
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
     
        $this->name = $row['name'];
    }
 
    // used by select drop-down list
    function read(){
        //select all data
        $query = "SELECT
                    id, name
                FROM
                    " . $this->table_name . "
                ORDER BY
                    name";  
 
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
 
        return $stmt;
    }

    // read all categories
    function readAll(){
 
        $query = "SELECT
                    id, name
                FROM
                    " . $this->table_name . "
                ORDER BY
                    name ASC";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        return $stmt;
    }

    // read all products in category
    function readCategoryProduct(){
 
        $query = "SELECT
                    id, name
                FROM
                    " . $this->table_name . "
                WHERE catSlug = ?
                ORDER BY
                    name ASC";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->catSlug);
        $stmt->execute();
     
        return $stmt;
    }

    // used to read category name by its ID
    function readName(){
         
        $query = "SELECT name FROM " . $this->table_name . " WHERE id = ? limit 0,1";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->id);
        $stmt->execute();
     
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
         
        $this->name = $row['name'];
    }

    // delete the product
    function delete(){
     
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    function deleteSubCat(){
     
        $query = "DELETE FROM  sub_categories WHERE catID = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }
 
}
?>