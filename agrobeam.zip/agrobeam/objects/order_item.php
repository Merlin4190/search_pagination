<?php
class OrderItem{
 
    // database connection and table name
    private $conn;
    private $table_name = "order_items";
 
    // object properties
    public $id;
    public $userID;
    public $amount;
    public $name;
    public $address;
    public $city;
    public $state;
    public $zip;
    public $payment_type;
    public $status;
    public $timestamp;
 
    public function __construct($db){
        $this->conn = $db;
    }

    // read all order items
    function readAll($from_record_num, $records_per_page){
 
        $query = "SELECT
                    *
                FROM
                    " . $this->table_name . "
                ORDER BY
                    orderID ASC
                LIMIT
                    {$from_record_num}, {$records_per_page}";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        return $stmt;
    }

    function readAllID($from_record_num, $records_per_page){
 
        $query = "SELECT
                    *
                FROM
                    " . $this->table_name . "
                WHERE sellerID = '".$_SESSION["user_id"]."' AND sellerDelete = 0
                ORDER BY
                    orderID ASC
                LIMIT
                    {$from_record_num}, {$records_per_page}";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        return $stmt;
    }

    // delete the order item
    function delete(){
     
        $query = "UPDATE " . $this->table_name . " 
            SET sellerDelete = 1  WHERE id = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    function deleteByAdmin(){
     
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    // used for seller's orders
    public function countAllSellerOrders(){
     
        $query = "SELECT id FROM " . $this->table_name . " 
            WHERE sellerID = '".$_SESSION["user_id"]."' AND sellerDelete = 0";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        $num = $stmt->rowCount();
     
        return $num;
    }

    // used for seller's earnings
    public function countAllSellerMonthlyEarnings(){
     
        $query = "SELECT SUM(i.item_price*i.quantity) AS amount, o.order_at  FROM " . $this->table_name . " i
            LEFT JOIN 
                orders o
                    ON o.id = i.orderID 
            WHERE  i.sellerID = '".$_SESSION["user_id"]."' AND i.sellerDelete = 0 
                AND MONTH(o.order_at) =  MONTH(CURRENT_DATE()) AND YEAR(o.order_at) = YEAR(CURRENT_DATE())";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        $sum = $stmt->fetch(PDO::FETCH_ASSOC);
     
        return $sum['amount'];
    }

    public function countAllSellerYearEarnings(){
     
        $query = "SELECT SUM(i.item_price*i.quantity) AS amount, o.order_at  FROM " . $this->table_name . " i
            LEFT JOIN 
                orders o
                    ON o.id = i.orderID 
            WHERE  i.sellerID = '".$_SESSION["user_id"]."' AND i.sellerDelete = 0 
                AND YEAR(o.order_at) = YEAR(CURRENT_DATE())";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        $sum = $stmt->fetch(PDO::FETCH_ASSOC);
     
        return $sum['amount'];
    }
}


?>