<?php
// 'user' object
class AffliateUser{
 
    // database connection and table name
    private $conn;
    private $table_name = "affliate_users";
 
    // object properties
    public $id;
    public $firstname;
    public $lastname;
    public $username;
    public $userSlug;
    public $email;
    public $contact_number;
    public $address;
    public $city;
    public $stateID;
    public $bank;
    public $account_number;
    // public $bvn;
    public $upload1;
    public $upload2;
    public $upload3;
    public $upload4;
    public $avatar;
    public $password;
    public $access_level;
    public $access_code;
    public $status;
    public $created;
    public $modified;
 
    // constructor
    public function __construct($db){
        $this->conn = $db;
    }

    function slug($text){ 

      // replace non letter or digits by -
      $text = preg_replace('~[^\\pL\d]+~u', '-', $text);

      // trim
      $text = trim($text, '-');

      // transliterate
      $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

      // lowercase
      $text = strtolower($text);

      // remove unwanted characters
      $text = preg_replace('~[^-\w]+~', '', $text);

      if (empty($text))
      {
        return 'n-a';
      }

      return $text;
    }

    // create new user record
    function create(){
     
        // to get time stamp for 'created' field
        $this->created=date('Y-m-d H:i:s');
     
        // insert query
        $query = "INSERT INTO " . $this->table_name . "
                SET
            firstname = :firstname,
            lastname = :lastname,
            username = :username,
            userSlug = :userSlug,
            email = :email,
            contact_number = :contact_number,
            address = :address,
            city = :city,
            stateID = :stateID,
            bank = :bank,
            account_number = :account_number,
            upload1 = :upload1,
            upload2 = :upload2,
            upload3 = :upload3,
            upload4 = :upload4,
            avatar = :avatar,
            password = :password,
            access_level = :access_level,
                    access_code = :access_code,
            status = :status,
            created = :created";
     
        // prepare the query
        $stmt = $this->conn->prepare($query);
     
        // sanitize
        $this->firstname=htmlspecialchars(strip_tags($this->firstname));
        $this->lastname=htmlspecialchars(strip_tags($this->lastname));
        $this->username=htmlspecialchars(strip_tags($this->username));
        $this->userSlug=htmlspecialchars(strip_tags($this->userSlug));
        $this->email=htmlspecialchars(strip_tags($this->email));
        $this->contact_number=htmlspecialchars(strip_tags($this->contact_number));
        $this->address=htmlspecialchars(strip_tags($this->address));
        $this->city=htmlspecialchars(strip_tags($this->city));
        $this->stateID=htmlspecialchars(strip_tags($this->stateID));
        $this->bank=htmlspecialchars(strip_tags($this->bank));
        $this->account_number=htmlspecialchars(strip_tags($this->account_number));
        // $this->bvn=htmlspecialchars(strip_tags($this->bvn));
        $this->upload1=htmlspecialchars(strip_tags($this->upload1));
        $this->upload2=htmlspecialchars(strip_tags($this->upload2));
        $this->upload3=htmlspecialchars(strip_tags($this->upload3));
        $this->upload4=htmlspecialchars(strip_tags($this->upload4));
        $this->avatar=htmlspecialchars(strip_tags($this->avatar));
        $this->password=htmlspecialchars(strip_tags($this->password));
        $this->access_level=htmlspecialchars(strip_tags($this->access_level));
        $this->access_code=htmlspecialchars(strip_tags($this->access_code));
        $this->status=htmlspecialchars(strip_tags($this->status));
     
        // bind the values
        $stmt->bindParam(':firstname', $this->firstname);
        $stmt->bindParam(':lastname', $this->lastname);
        $stmt->bindParam(':username', $this->username);
        $stmt->bindParam(':userSlug', $this->userSlug);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':contact_number', $this->contact_number);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':city', $this->city);
        $stmt->bindParam(':stateID', $this->stateID);
        $stmt->bindParam(':bank', $this->bank);
        $stmt->bindParam(':account_number', $this->account_number);
        // $stmt->bindParam(':bvn', $this->bvn);
        $stmt->bindParam(':upload1', $this->upload1);
        $stmt->bindParam(':upload2', $this->upload2);
        $stmt->bindParam(':upload3', $this->upload3);
        $stmt->bindParam(':upload4', $this->upload4);
        $stmt->bindParam(':avatar', $this->avatar);
     
        // hash the password before saving to database
        $password_hash = password_hash($this->password, PASSWORD_BCRYPT);
        $stmt->bindParam(':password', $password_hash);
     
        $stmt->bindParam(':access_level', $this->access_level);
        $stmt->bindParam(':access_code', $this->access_code);
        $stmt->bindParam(':status', $this->status);
        $stmt->bindParam(':created', $this->created);
     
        // execute the query, also check if query was successful
        if($stmt->execute()){
            return true;
        }else{
            $this->showError($stmt);
            return false;
        }
     
    }

    // will upload image file to server
    function uploadPhoto(){
     
        $result_message="";
     
        // now, if image is not empty, try to upload the image        

        if($this->avatar){
     
            // sha1_file() function is used to make a unique file name
            $target_directory = "avatars/";
            $target_file = $target_directory . $this->avatar;
            $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
     
            // error message is empty
            $file_upload_error_messages="";

            // make sure that file is a real image
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check!==false){
                // submitted file is an image
            }
             
            // make sure certain file types are allowed
            $allowed_file_types=array("jpg", "jpeg", "png", "gif", "pdf");
            if(!in_array($file_type, $allowed_file_types)){
                $file_upload_error_messages.="<div>Only JPG, JPEG, PNG, GIF, PDF files are allowed.</div>";
            }
             
            // make sure file does not exist
            if(file_exists($target_file)){
                $file_upload_error_messages.="<div>File already exists. Try to change file name.</div>";
            }
             
            // make sure submitted file is not too large, can't be larger than 5 MB
            if($_FILES['image']['size'] > (5024000)){
                $file_upload_error_messages.="<div>File must be less than 5 MB in size.</div>";
            }
             
            // make sure the 'uploaded_documents' folder exists
            // if not, create it
            if(!is_dir($target_directory)){
                mkdir($target_directory, 0777, true);
            }

            // if $file_upload_error_messages is still empty
            if(empty($file_upload_error_messages)){
                // it means there are no errors, so try to upload the file
                if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
                    // it means photo was uploaded
                }else{
                    $result_message.="<div class='error'>";
                        $result_message.="<div>Unable to upload photo.</div>";
                        $result_message.="<div>Update the record to upload avatar.</div>";
                    $result_message.="</div>";
                }
            }
             
            // if $file_upload_error_messages is NOT empty
            else{
                // it means there are some errors, so show them to user
                $result_message.="<div class='error'>";
                    $result_message.="{$file_upload_error_messages}";
                    $result_message.="<div>Update the record to upload avatar.</div>";
                $result_message.="</div>";
            }
     
        }
     
        return $result_message;
    }

    // will upload file to server
    function uploadValidID(){
     
        $result_message="";
     
        // now, if file is not empty, try to upload the file        

        if($this->upload1){
     
            // sha1_file() function is used to make a unique file name
            $target_directory = "../account/uploaded_documents/";
            $target_file = $target_directory . $this->upload1;
            $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
     
            // error message is empty
            $file_upload_error_messages="";

            // make sure that file is a real image
            $check = getimagesize($_FILES["image1"]["tmp_name"]);
            if($check!==false){
                // submitted file is an image
            }
             
            // make sure certain file types are allowed
            $allowed_file_types=array("jpg", "jpeg", "png", "gif", "pdf");
            if(!in_array($file_type, $allowed_file_types)){
                $file_upload_error_messages.="<div>Only JPG, JPEG, PNG, GIF, PDF files are allowed.</div>";
            }
             
            // make sure file does not exist
            if(file_exists($target_file)){
                $file_upload_error_messages.="<div>File already exists. Try to change file name.</div>";
            }
             
            // make sure submitted file is not too large, can't be larger than 5 MB
            if($_FILES['image1']['size'] > (5024000)){
                $file_upload_error_messages.="<div>File must be less than 5 MB in size.</div>";
            }
             
            // make sure the 'uploaded_documents' folder exists
            // if not, create it
            if(!is_dir($target_directory)){
                mkdir($target_directory, 0777, true);
            }

            // if $file_upload_error_messages is still empty
            if(empty($file_upload_error_messages)){
                // it means there are no errors, so try to upload the file
                if(move_uploaded_file($_FILES["image1"]["tmp_name"], $target_file)){
                    // it means photo was uploaded
                }else{
                    $result_message.="<div class='error'>";
                        $result_message.="<div>Unable to upload photo.</div>";
                        $result_message.="<div>Update the record to upload valid identificaton.</div>";
                    $result_message.="</div>";
                }
            }
             
            // if $file_upload_error_messages is NOT empty
            else{
                // it means there are some errors, so show them to user
                $result_message.="<div class='error'>";
                    $result_message.="{$file_upload_error_messages}";
                    $result_message.="<div>Update the record to upload valid identificaton.</div>";
                $result_message.="</div>";
            }
     
        }
     
        return $result_message;
    }

    // will upload file to server
    function uploadUtilityBill(){
     
        $result_message="";
     
        // now, if file is not empty, try to upload the file
        if($this->upload2){
     
            // sha1_file() function is used to make a unique file name
            $target_directory = "../account/uploaded_documents/";
            $target_file = $target_directory . $this->upload2;
            $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
     
            // error message is empty
            $file_upload_error_messages="";

            // make sure that file is a real image
            $check = getimagesize($_FILES["image2"]["tmp_name"]);
            if($check!==false){
                // submitted file is an image
            }
             
            // make sure certain file types are allowed
            $allowed_file_types=array("jpg", "jpeg", "png", "gif", "pdf");
            if(!in_array($file_type, $allowed_file_types)){
                $file_upload_error_messages.="<div>Only JPG, JPEG, PNG, GIF, PDF files are allowed.</div>";
            }
             
            // make sure file does not exist
            if(file_exists($target_file)){
                $file_upload_error_messages.="<div>File already exists. Try to change file name.</div>";
            }
             
            // make sure submitted file is not too large, can't be larger than 5 MB
            if($_FILES['image2']['size'] > (5024000)){
                $file_upload_error_messages.="<div>File must be less than 5 MB in size.</div>";
            }
             
            // make sure the 'uploaded_documents' folder exists
            // if not, create it
            if(!is_dir($target_directory)){
                mkdir($target_directory, 0777, true);
            }

            // if $file_upload_error_messages is still empty
            if(empty($file_upload_error_messages)){
                // it means there are no errors, so try to upload the file
                if(move_uploaded_file($_FILES["image2"]["tmp_name"], $target_file)){
                    // it means photo was uploaded
                }else{
                    $result_message.="<div class='error'>";
                        $result_message.="<div>Unable to upload photo.</div>";
                        $result_message.="<div>Update the record to upload utility bill.</div>";
                    $result_message.="</div>";
                }
            }
             
            // if $file_upload_error_messages is NOT empty
            else{
                // it means there are some errors, so show them to user
                $result_message.="<div class='error'>";
                    $result_message.="{$file_upload_error_messages}";
                    $result_message.="<div>Update the record to upload utility bill.</div>";
                $result_message.="</div>";
            }
     
        }
     
        return $result_message;
    }

    // will upload file to server
    function uploadEvidence(){
     
        $result_message="";
     
        // now, if file is not empty, try to upload the file
        if($this->upload3){
     
            // sha1_file() function is used to make a unique file name
            $target_directory = "../account/uploaded_documents/";
            $target_file = $target_directory . $this->upload3;
            $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
     
            // error message is empty
            $file_upload_error_messages="";

            // make sure that file is a real image
            $check = getimagesize($_FILES["image3"]["tmp_name"]);
            if($check!==false){
                // submitted file is an image
            }
             
            // make sure certain file types are allowed
            $allowed_file_types=array("jpg", "jpeg", "png", "gif", "pdf");
            if(!in_array($file_type, $allowed_file_types)){
                $file_upload_error_messages.="<div>Only JPG, JPEG, PNG, GIF, PDF files are allowed.</div>";
            }
             
            // make sure file does not exist
            if(file_exists($target_file)){
                $file_upload_error_messages.="<div>File already exists. Try to change file name.</div>";
            }
             
            // make sure submitted file is not too large, can't be larger than 5 MB
            if($_FILES['image3']['size'] > (5024000)){
                $file_upload_error_messages.="<div>File must be less than 5 MB in size.</div>";
            }
             
            // make sure the 'uploaded_documents' folder exists
            // if not, create it
            if(!is_dir($target_directory)){
                mkdir($target_directory, 0777, true);
            }

            // if $file_upload_error_messages is still empty
            if(empty($file_upload_error_messages)){
                // it means there are no errors, so try to upload the file
                if(move_uploaded_file($_FILES["image3"]["tmp_name"], $target_file)){
                    // it means photo was uploaded
                }else{
                    $result_message.="<div class='error'>";
                        $result_message.="<div>Unable to upload photo.</div>";
                        $result_message.="<div>Update the record to upload evidence of farming.</div>";
                    $result_message.="</div>";
                }
            }
             
            // if $file_upload_error_messages is NOT empty
            else{
                // it means there are some errors, so show them to user
                $result_message.="<div class='error'>";
                    $result_message.="{$file_upload_error_messages}";
                    $result_message.="<div>Update the record to upload evidence of farming.</div>";
                $result_message.="</div>";
            }
     
        }
     
        return $result_message;
    }

    // will upload file to server
    function uploadCertificate(){
     
        $result_message="";
     
        // now, if file is not empty, try to upload the file
        if($this->upload4){
     
            // sha1_file() function is used to make a unique file name
            $target_directory = "../account/uploaded_documents/";
            $target_file = $target_directory . $this->upload4;
            $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
     
            // error message is empty
            $file_upload_error_messages="";

            // make sure that file is a real image
            $check = getimagesize($_FILES["image4"]["tmp_name"]);
            if($check!==false){
                // submitted file is an image
            }
             
            // make sure certain file types are allowed
            $allowed_file_types=array("jpg", "jpeg", "png", "gif", "pdf");
            if(!in_array($file_type, $allowed_file_types)){
                $file_upload_error_messages.="<div>Only JPG, JPEG, PNG, GIF, PDF files are allowed.</div>";
            }
             
            // make sure file does not exist
            if(file_exists($target_file)){
                $file_upload_error_messages.="<div>File already exists. Try to change file name.</div>";
            }
             
            // make sure submitted file is not too large, can't be larger than 5 MB
            if($_FILES['image4']['size'] > (5024000)){
                $file_upload_error_messages.="<div>File must be less than 5 MB in size.</div>";
            }
             
            // make sure the 'uploaded_documents' folder exists
            // if not, create it
            if(!is_dir($target_directory)){
                mkdir($target_directory, 0777, true);
            }

            // if $file_upload_error_messages is still empty
            if(empty($file_upload_error_messages)){
                // it means there are no errors, so try to upload the file
                if(move_uploaded_file($_FILES["image4"]["tmp_name"], $target_file)){
                    // it means photo was uploaded
                }else{
                    $result_message.="<div class='error'>";
                        $result_message.="<div>Unable to upload photo.</div>";
                        $result_message.="<div>Update the record to upload certificate.</div>";
                    $result_message.="</div>";
                }
            }
             
            // if $file_upload_error_messages is NOT empty
            else{
                // it means there are some errors, so show them to user
                $result_message.="<div class='error'>";
                    $result_message.="{$file_upload_error_messages}";
                    $result_message.="<div>Update the record to upload certificate.</div>";
                $result_message.="</div>";
            }
     
        }
     
        return $result_message;
    }

    // update user
    function update(){
 
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    firstname=:firstname, lastname=:lastname, username=:username, userSlug=:userSlug,
                        contact_number=:contact_number, address=:address, city=:city, stateID=:stateID, bank=:bank, account_number=:account_number, bvn=:bvn, banner=:banner, avatar=:avatar, gender=:gender, bio=:bio, birthday=:birthday 
                WHERE
                    id = :id";
     
        $stmt = $this->conn->prepare($query);
     
        // posted values
        $this->firstname=htmlspecialchars(strip_tags($this->firstname));
        $this->lastname=htmlspecialchars(strip_tags($this->lastname));
        $this->username=htmlspecialchars(strip_tags($this->username));
        $this->userSlug=htmlspecialchars(strip_tags($this->userSlug));
        $this->contact_number=htmlspecialchars(strip_tags($this->contact_number));
        $this->address=htmlspecialchars(strip_tags($this->address));
        $this->city=htmlspecialchars(strip_tags($this->city));
        $this->stateID=htmlspecialchars(strip_tags($this->stateID));
        $this->gender=htmlspecialchars(strip_tags($this->gender));
        $this->birthday=htmlspecialchars(strip_tags($this->birthday));
        $this->bio=htmlspecialchars(strip_tags($this->bio));
        $this->avatar=htmlspecialchars(strip_tags($this->avatar));
        $this->banner=htmlspecialchars(strip_tags($this->banner));
        $this->bank=htmlspecialchars(strip_tags($this->bank));
        $this->bvn=htmlspecialchars(strip_tags($this->bvn));
        $this->account_number=htmlspecialchars(strip_tags($this->account_number));
        $this->id=htmlspecialchars(strip_tags($this->id));
     
        // bind parameters
        $stmt->bindParam(':firstname', $this->firstname);
        $stmt->bindParam(':lastname', $this->lastname);
        $stmt->bindParam(':username', $this->username);
        $stmt->bindParam(':userSlug', $this->userSlug);
        $stmt->bindParam(':contact_number', $this->contact_number);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':city', $this->city);
        $stmt->bindParam(':stateID', $this->stateID);
        $stmt->bindParam(':gender', $this->gender);
        $stmt->bindParam(':birthday', $this->birthday);
        $stmt->bindParam(':bio', $this->bio);
        $stmt->bindParam(':avatar', $this->avatar);
        $stmt->bindParam(':banner', $this->banner);
        $stmt->bindParam(':bank', $this->bank);
        $stmt->bindParam(':bvn', $this->bvn);
        $stmt->bindParam(':account_number', $this->account_number);
        $stmt->bindParam(':id', $this->id);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
         
    }

    // update user
    function updateSeller(){
 
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    firstname=:firstname, lastname=:lastname,
                        email=:email, contact_number=:contact_number
                WHERE
                    id = :id";
     
        $stmt = $this->conn->prepare($query);
     
        // posted values
        $this->firstname=htmlspecialchars(strip_tags($this->firstname));
        $this->lastname=htmlspecialchars(strip_tags($this->lastname));
        $this->contact_number=htmlspecialchars(strip_tags($this->contact_number));
        $this->email=htmlspecialchars(strip_tags($this->email));
        $this->id=htmlspecialchars(strip_tags($this->id));
     
        // bind parameters
        $stmt->bindParam(':firstname', $this->firstname);
        $stmt->bindParam(':lastname', $this->lastname);
        $stmt->bindParam(':contact_number', $this->contact_number);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':id', $this->id);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;         
    }

    function updateDocument1(){
 
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    upload1=:upload1
                WHERE
                    id = :id";
     
        $stmt = $this->conn->prepare($query);
     
        // posted values        
        $this->upload1=htmlspecialchars(strip_tags($this->upload1));
        $this->id=htmlspecialchars(strip_tags($this->id));
     
        // bind parameters        
        $stmt->bindParam(':upload1', $this->upload1);
        $stmt->bindParam(':id', $this->id);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
         
    }

    function updateDocument2(){
 
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    upload2=:upload2
                WHERE
                    id = :id";
     
        $stmt = $this->conn->prepare($query);
     
        // posted values
        $this->upload2=htmlspecialchars(strip_tags($this->upload2));
        $this->id=htmlspecialchars(strip_tags($this->id));
     
        // bind parameters
        $stmt->bindParam(':upload2', $this->upload2);
        $stmt->bindParam(':id', $this->id);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
         
    }

    function updateDocument3(){
 
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    Upload3=:upload3
                WHERE
                    id = :id";
     
        $stmt = $this->conn->prepare($query);
     
        // posted values
        $this->upload3=htmlspecialchars(strip_tags($this->upload3));
        $this->id=htmlspecialchars(strip_tags($this->id));
     
        // bind parameters
        $stmt->bindParam(':upload3', $this->upload3);
        $stmt->bindParam(':id', $this->id);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
         
    }
    function updateDocument4(){
 
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    upload4=:upload4
                WHERE
                    id = :id";
     
        $stmt = $this->conn->prepare($query);
     
        // posted values
        $this->upload4=htmlspecialchars(strip_tags($this->upload4));
        $this->id=htmlspecialchars(strip_tags($this->id));
     
        // bind parameters
        $stmt->bindParam(':upload4', $this->upload4);
        $stmt->bindParam(':id', $this->id);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
         
    }

    function updateAvatar(){
 
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    avatar=:avatar
                WHERE
                    id = :id";
     
        $stmt = $this->conn->prepare($query);
     
        // posted values        
        $this->avatar=htmlspecialchars(strip_tags($this->avatar));        
        $this->id=htmlspecialchars(strip_tags($this->id));
     
        // bind parameters        
        $stmt->bindParam(':avatar', $this->avatar);
        $stmt->bindParam(':id', $this->id);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
         
    }

    function updateBanner(){
 
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    banner=:banner
                WHERE
                    id = :id";
     
        $stmt = $this->conn->prepare($query);
     
        // posted values        
        $this->banner=htmlspecialchars(strip_tags($this->banner));        
        $this->id=htmlspecialchars(strip_tags($this->id));
     
        // bind parameters        
        $stmt->bindParam(':banner', $this->banner);
        $stmt->bindParam(':id', $this->id);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
         
    }

    // will upload image file to server
    function uploadUpdatedAvatar(){
     
        $result_message="";
     
        // now, if image is not empty, try to upload the image        

        if($this->avatar){
     
            // sha1_file() function is used to make a unique file name
            $target_directory = "../account/avatars/";
            $target_file = $target_directory . $this->avatar;
            $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
     
            // error message is empty
            $file_upload_error_messages="";

            // make sure that file is a real image
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check!==false){
                // submitted file is an image
            }else{
                $file_upload_error_messages.="<div>Submitted file is not an image.</div>";
            }
             
            // make sure certain file types are allowed
            $allowed_file_types=array("jpg", "jpeg", "png", "gif", "pdf");
            if(!in_array($file_type, $allowed_file_types)){
                $file_upload_error_messages.="<div>Only JPG, JPEG, PNG, GIF, PDF files are allowed.</div>";
            }
             
            // make sure file does not exist
            if(file_exists($target_file)){
                $file_upload_error_messages.="<div>File already exists. Try to change file name.</div>";
            }
             
            // make sure submitted file is not too large, can't be larger than 5 MB
            if($_FILES['image']['size'] > (5024000)){
                $file_upload_error_messages.="<div>File must be less than 5 MB in size.</div>";
            }
             
            // make sure the 'uploaded_documents' folder exists
            // if not, create it
            if(!is_dir($target_directory)){
                mkdir($target_directory, 0777, true);
            }

            // if $file_upload_error_messages is still empty
            if(empty($file_upload_error_messages)){
                // it means there are no errors, so try to upload the file
                if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
                    // it means photo was uploaded
                }else{
                    $result_message.="<div class='error'>";
                        $result_message.="<div>Unable to upload photo.</div>";
                        $result_message.="<div>Update the record to upload avatar.</div>";
                    $result_message.="</div>";
                }
            }
             
            // if $file_upload_error_messages is NOT empty
            else{
                // it means there are some errors, so show them to user
                $result_message.="<div class='error'>";
                    $result_message.="{$file_upload_error_messages}";
                    $result_message.="<div>Update the record to upload avatar.</div>";
                $result_message.="</div>";
            }
     
        }
     
        return $result_message;
    }

    // will upload image file to server
    function uploadUpdatedBanner(){
     
        $result_message="";
     
        // now, if image is not empty, try to upload the image        

        if($this->banner){
     
            // sha1_file() function is used to make a unique file name
            $target_directory = "../account/banners/";
            $target_file = $target_directory . $this->banner;
            $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
     
            // error message is empty
            $file_upload_error_messages="";

            // make sure that file is a real image
            $check = getimagesize($_FILES["banner"]["tmp_name"]);
            if($check!==false){
                // submitted file is an image
            }else{
                $file_upload_error_messages.="<div>Submitted file is not an image.</div>";
            }
             
            // make sure certain file types are allowed
            $allowed_file_types=array("jpg", "jpeg", "png", "gif", "pdf");
            if(!in_array($file_type, $allowed_file_types)){
                $file_upload_error_messages.="<div>Only JPG, JPEG, PNG, GIF, PDF files are allowed.</div>";
            }
             
            // make sure file does not exist
            if(file_exists($target_file)){
                $file_upload_error_messages.="<div>File already exists. Try to change file name.</div>";
            }
             
            // make sure submitted file is not too large, can't be larger than 5 MB
            if($_FILES['banner']['size'] > (5024000)){
                $file_upload_error_messages.="<div>File must be less than 5 MB in size.</div>";
            }
             
            // make sure the 'uploaded_documents' folder exists
            // if not, create it
            if(!is_dir($target_directory)){
                mkdir($target_directory, 0777, true);
            }

            // if $file_upload_error_messages is still empty
            if(empty($file_upload_error_messages)){
                // it means there are no errors, so try to upload the file
                if(move_uploaded_file($_FILES["banner"]["tmp_name"], $target_file)){
                    // it means photo was uploaded
                }else{
                    $result_message.="<div class='error'>";
                        $result_message.="<div>Unable to upload photo.</div>";
                        $result_message.="<div>Update the record to upload banner.</div>";
                    $result_message.="</div>";
                }
            }
             
            // if $file_upload_error_messages is NOT empty
            else{
                // it means there are some errors, so show them to user
                $result_message.="<div class='error'>";
                    $result_message.="{$file_upload_error_messages}";
                    $result_message.="<div>Update the record to upload banner.</div>";
                $result_message.="</div>";
            }
     
        }
     
        return $result_message;
    }

    // used in profile settings to change password
    function change_password(){
        // update query
        $query = "UPDATE " . $this->table_name . "
                SET password = :new_password
                WHERE id = :id";
     
        $stmt = $this->conn->prepare($query);
     
        // posted values        
        $this->new_password=htmlspecialchars(strip_tags($this->new_password));
        $this->id=htmlspecialchars(strip_tags($this->id));
     
        // bind parameters        
        // hash the password before saving to database
        $password_hash = password_hash($this->new_password, PASSWORD_BCRYPT);
        $stmt->bindParam(':new_password', $password_hash);
        $stmt->bindParam(':id', $this->id);

        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false; 
    }

    // used in forgot password feature
    function updatePassword(){
     
        // update query
        $query = "UPDATE " . $this->table_name . "
                SET password = :password
                WHERE access_code = :access_code";
     
        // prepare the query
        $stmt = $this->conn->prepare($query);
     
        // sanitize
        $this->password=htmlspecialchars(strip_tags($this->password));
        $this->access_code=htmlspecialchars(strip_tags($this->access_code));
     
        // bind the values from the form
        $password_hash = password_hash($this->password, PASSWORD_BCRYPT);
        $stmt->bindParam(':password', $password_hash);
        $stmt->bindParam(':access_code', $this->access_code);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
    }    

    // used in forgot password feature
    function updateAccessCode(){
     
        // update query
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    access_code = :access_code
                WHERE
                    email = :email";
     
        // prepare the query
        $stmt = $this->conn->prepare($query);
     
        // sanitize
        $this->access_code=htmlspecialchars(strip_tags($this->access_code));
        $this->email=htmlspecialchars(strip_tags($this->email));
     
        // bind the values from the form
        $stmt->bindParam(':access_code', $this->access_code);
        $stmt->bindParam(':email', $this->email);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
    }

    // used in email verification feature
    function updateStatusByAccessCode(){
     
        // update query
        $query = "UPDATE " . $this->table_name . "
                SET status = :status
                WHERE access_code = :access_code";
     
        // prepare the query
        $stmt = $this->conn->prepare($query);
     
        // sanitize
        $this->status=htmlspecialchars(strip_tags($this->status));
        $this->access_code=htmlspecialchars(strip_tags($this->access_code));
     
        // bind the values from the form
        $stmt->bindParam(':status', $this->status);
        $stmt->bindParam(':access_code', $this->access_code);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
    }

    // check if given email exist in the database
    function emailExists(){
     
        // query to check if email exists
        $query = "SELECT id, firstname, lastname, avatar, contact_number, address, city, stateID, access_level, password, status
                FROM " . $this->table_name . "
                WHERE email = ?
                LIMIT 0,1";
     
        // prepare the query
        $stmt = $this->conn->prepare( $query );
     
        // sanitize
        $this->email=htmlspecialchars(strip_tags($this->email));
     
        // bind given email value
        $stmt->bindParam(1, $this->email);
     
        // execute the query
        $stmt->execute();
     
        // get number of rows
        $num = $stmt->rowCount();
     
        // if email exists, assign values to object properties for easy access and use for php sessions
        if($num>0){
     
            // get record details / values
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
     
            // assign values to object properties
            $this->id = $row['id'];
            $this->firstname = $row['firstname'];
            $this->lastname = $row['lastname'];
            // $this->username = $row['username'];
            $this->contact_number = $row['contact_number'];
            $this->address = $row['address'];
            $this->city = $row['city'];
            $this->stateID = $row['stateID'];
            $this->access_level = $row['access_level'];
            $this->avatar = $row['avatar'];
            $this->password = $row['password'];
            $this->status = $row['status'];
     
            // return true because email exists in the database
            return true;
        }
     
        // return false if email does not exist in the database
        return false;
    }

    // check if given email exist in the database
    function usernameExists(){
     
        // query to check if email exists
        $query = "SELECT id, firstname, lastname, avatar, contact_number, address, city, stateID, access_level, password, status
                FROM " . $this->table_name . "
                WHERE username = ?
                LIMIT 0,1";
     
        // prepare the query
        $stmt = $this->conn->prepare( $query );
     
        // sanitize
        $this->username=htmlspecialchars(strip_tags($this->username));
     
        // bind given username value
        $stmt->bindParam(1, $this->username);
     
        // execute the query
        $stmt->execute();
     
        // get number of rows
        $num = $stmt->rowCount();
     
        // if username exists, assign values to object properties for easy access and use for php sessions
        if($num>0){
            // get record details / values
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
     
            // assign values to object properties
            $this->id = $row['id'];
            $this->firstname = $row['firstname'];
            $this->lastname = $row['lastname'];
            // $this->username = $row['username'];
            $this->contact_number = $row['contact_number'];
            $this->address = $row['address'];
            $this->city = $row['city'];
            $this->stateID = $row['stateID'];
            $this->access_level = $row['access_level'];
            $this->avatar = $row['avatar'];
            $this->password = $row['password'];
            $this->status = $row['status'];
     
            // return true because username exists in the database
            return true;
        }
     
        // return false if username does not exist in the database
        return false;
    }

    // check if given access_code exist in the database
    function accessCodeExists(){
     
        // query to check if access_code exists
        $query = "SELECT id
                FROM " . $this->table_name . "
                WHERE access_code = ?
                LIMIT 0,1";
     
        // prepare the query
        $stmt = $this->conn->prepare( $query );
     
        // sanitize
        $this->access_code=htmlspecialchars(strip_tags($this->access_code));
     
        // bind given access_code value
        $stmt->bindParam(1, $this->access_code);
     
        // execute the query
        $stmt->execute();
     
        // get number of rows
        $num = $stmt->rowCount();
     
        // if access_code exists
        if($num>0){
     
            // return true because access_code exists in the database
            return true;
        }
     
        // return false if access_code does not exist in the database
        return false;
     
    }

    public function showError($stmt){
        echo "<pre>";
            print_r($stmt->errorInfo());
        echo "</pre>";
    }

    // read one user
    function readOne(){
 
        $query = "SELECT firstname, lastname, username, contact_number, address, city, stateID, avatar, banner, bio, gender, birthday, bvn, bank, account_number, upload1, upload2, upload3, upload4
            FROM " . $this->table_name . "
            WHERE id = ?
            LIMIT 0,1";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->id);
        $stmt->execute();
     
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
     
        $this->firstname = $row['firstname'];
        $this->lastname = $row['lastname'];
        $this->username = $row['username'];
        $this->gender = $row['gender'];
        $this->birthday = $row['birthday'];
        $this->contact_number = $row['contact_number'];
        $this->city = $row['city'];
        $this->stateID = $row['stateID'];
        $this->avatar = $row['avatar'];
        $this->upload1 = $row['upload1'];
        $this->upload2 = $row['upload2'];
        $this->upload3 = $row['upload3'];
        $this->upload4 = $row['upload4'];
        $this->address = $row['address'];
        $this->banner = $row['banner'];
        $this->bio = $row['bio'];
        $this->bank = $row['bank'];
        $this->account_number = $row['account_number'];
        $this->bvn = $row['bvn'];
        $this->bio = $row['bio'];
    }

    // read all user records
    function readAll($from_record_num, $records_per_page){
     
        // query to read all user records, with limit clause for pagination
        $query = "SELECT
                    id,
                    firstname,
                    lastname,
                    email,
                    contact_number,
                    access_level,
                    created
                FROM " . $this->table_name . "
                ORDER BY id DESC
                LIMIT ?, ?";
     
        // prepare query statement
        $stmt = $this->conn->prepare( $query );
     
        // bind limit clause variables
        $stmt->bindParam(1, $from_record_num, PDO::PARAM_INT);
        $stmt->bindParam(2, $records_per_page, PDO::PARAM_INT);
     
        // execute query
        $stmt->execute();
     
        // return values
        return $stmt;
    }
    // read all user records
    function readAllSellers($from_record_num, $records_per_page){
     
        // query to read all user records, with limit clause for pagination
        $query = "SELECT
                    id,
                    firstname,
                    lastname,
                    username,
                    email,
                    address,
                    city, 
                    stateID,
                    contact_number,
                    access_level,
                    upload1,
                    upload2,
                    upload3,
                    upload4,
                    verification_status,
                    created
                FROM " . $this->table_name . "
                WHERE access_level = 'Seller'
                ORDER BY id DESC
                LIMIT ?, ?";
     
        // prepare query statement
        $stmt = $this->conn->prepare( $query );
     
        // bind limit clause variables
        $stmt->bindParam(1, $from_record_num, PDO::PARAM_INT);
        $stmt->bindParam(2, $records_per_page, PDO::PARAM_INT);
     
        // execute query
        $stmt->execute();
     
        // return values
        return $stmt;
    }

    // delete the documents
    function deleteUpload1(){
     
        $query = "UPDATE " . $this->table_name . " 
            SET upload1 = null WHERE id = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    function deleteUpload2(){
     
        $query = "UPDATE " . $this->table_name . " 
            SET upload2 = null WHERE id = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    function deleteUpload3(){
     
        $query = "UPDATE " . $this->table_name . " 
            SET upload3 = null WHERE id = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    function deleteUpload4(){
     
        $query = "UPDATE " . $this->table_name . " 
            SET upload4 = null WHERE id = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    // delete the seller's account
    function deleteSellerBYAdmin(){
     
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    // verify the sellers by admin
    function verifyByAdmin(){
     
        $query = "UPDATE " . $this->table_name . " 
            SET verification_status = 1 WHERE id = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    function unverifyByAdmin(){
     
        $query = "UPDATE " . $this->table_name . " 
            SET verification_status = 0 WHERE id = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    // used for paging users
    public function countAll(){
     
        // query to select all user records
        $query = "SELECT id FROM " . $this->table_name . "";
     
        // prepare query statement
        $stmt = $this->conn->prepare($query);
     
        // execute query
        $stmt->execute();
     
        // get number of rows
        $num = $stmt->rowCount();
     
        // return row count
        return $num;
    }

    public function countAllSellers(){
     
        // query to select all user records
        $query = "SELECT id FROM " . $this->table_name . " WHERE access_level = 'Seller'";
     
        // prepare query statement
        $stmt = $this->conn->prepare($query);
     
        // execute query
        $stmt->execute();
     
        // get number of rows
        $num = $stmt->rowCount();
     
        // return row count
        return $num;
    }

    public function countAllVerifiedSellers(){
     
        // query to select all user records
        $query = "SELECT id FROM " . $this->table_name . " WHERE access_level = 'Seller' AND verification_status = '1'";
     
        // prepare query statement
        $stmt = $this->conn->prepare($query);
     
        // execute query
        $stmt->execute();
     
        // get number of rows
        $num = $stmt->rowCount();
     
        // return row count
        return $num;
    }
}