<?php
class Order{
 
    // database connection and table name
    private $conn;
    private $table_name = "orders";
 
    // object properties
    public $id;
    public $userID;
    public $amount;
    public $name;
    public $address;
    public $city;
    public $state;
    public $zip;
    public $payment_type;
    public $status;
    public $timestamp;
 
    public function __construct($db){
        $this->conn = $db;
    }

    // read all orders
    function readAll($from_record_num, $records_per_page){
 
        $query = "SELECT
                    *
                FROM
                    " . $this->table_name . "
                ORDER BY
                    id ASC
                LIMIT
                    {$from_record_num}, {$records_per_page}";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        return $stmt;
    }

    // update category
    function update(){
 
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    delivery_status = :status,
                    id = :id,
                    order_at = order_at,
                    delivery_date = :modified
                WHERE
                    id = :id";
     
        $stmt = $this->conn->prepare($query);
     
        // posted values
        $this->delivery_status=htmlspecialchars(strip_tags($this->delivery_status));
        $this->id=htmlspecialchars(strip_tags($this->id));

        // to get time-stamp for 'created' field
        $this->timestamp = date('Y-m-d H:i:s');
     
        // bind parameters
        $stmt->bindParam(':status', $this->delivery_status);
        $stmt->bindParam(':id', $this->id);
        $stmt->bindParam(":modified", $this->timestamp);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
         
    }

    // delete the orders
    function delete(){
     
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
         
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
     
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    // used for counting orders
    public function countAll(){
     
        $query = "SELECT id FROM " . $this->table_name . " ";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        $num = $stmt->rowCount();
     
        return $num;
    }

    // used for suming earnings
    public function countAllMonthlyEarnings(){
     
        $query = "SELECT SUM(amount) as amount  FROM " . $this->table_name . "
            WHERE MONTH(order_at) =  MONTH(CURRENT_DATE()) AND YEAR(order_at) = YEAR(CURRENT_DATE())";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        $sum = $stmt->fetch(PDO::FETCH_ASSOC);
     
        return $sum['amount'];
    }

    public function countAllYearlyEarnings(){
     
        $query = "SELECT SUM(amount) as amount  FROM " . $this->table_name . "
            WHERE YEAR(order_at) = YEAR(CURRENT_DATE())";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        $sum = $stmt->fetch(PDO::FETCH_ASSOC);
     
        return $sum['amount'];
    }
}


?>