<?php
class Message{
 
    // database connection and table name
    private $conn;
    private $table_name = "messages";
 
    // object properties
    public $messageID;
    public $senderID;
    public $receiverID;
    public $subject;
    public $message;
    public $status1;
    public $status2;
    public $timestamp;
 
    public function __construct($db){
        $this->conn = $db;
    }
 
    // create product
    function create(){
 
        //write query
        // insert query
        $query = "INSERT INTO " . $this->table_name . "
                    SET senderID=:senderID, receiverID=:receiverID, subject=:subject, message=:message, sender_view_status=:status1, timestamp=:created";
 
        $stmt = $this->conn->prepare($query);
 
        // posted values
        $this->senderID=htmlspecialchars(strip_tags($this->senderID));
        $this->receiverID=htmlspecialchars(strip_tags($this->receiverID));
        $this->subject=htmlspecialchars(strip_tags($this->subject));
        $this->message=htmlspecialchars(strip_tags($this->message));
        $this->status1=htmlspecialchars(strip_tags($this->status));
 
        // to get time-stamp for 'created' field
        $this->timestamp = date('Y-m-d H:i:s');
 
        // bind values 
        $stmt->bindParam(":senderID", $this->senderID);
        $stmt->bindParam(":receiverID", $this->receiverID);
        $stmt->bindParam(":subject", $this->subject);
        $stmt->bindParam(":message", $this->message);
        $stmt->bindParam(":status1", $this->status1);
        $stmt->bindParam(":created", $this->timestamp);        
 
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
 
    }

    // read one msg
    function readOne(){
 
        $query = "SELECT subject, receiverID, message, timestamp
            FROM " . $this->table_name . "
            WHERE messageID = ?
            LIMIT 0,1";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->id);
        $stmt->execute();
     
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        $this->subject = $row['subject'];
        $this->receiverID = $row['receiverID'];
        $this->message = $row['message'];
        $this->timestamp = $row['timestamp'];
    }

    function readSentMsgByAdmin($from_record_num, $records_per_page){
 
        $query = "SELECT
                    messageID, subject, senderID, receiverID, timestamp
                FROM
                    " . $this->table_name . "
                WHERE senderID = '".$_SESSION['firstname']."' 
                ORDER BY
                    messageID ASC
                LIMIT
                    {$from_record_num}, {$records_per_page}";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        return $stmt;
    }
}
?>